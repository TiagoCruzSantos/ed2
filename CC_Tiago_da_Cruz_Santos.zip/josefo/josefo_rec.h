#ifndef __JOSEFO__
#define __JOSEFO__

int select_josefo(int n, int m);

#endif